package com.miedviediev.cs.Practice3.Servers;

public class StoreServerUDP {
}
