package com.miedviediev.cs.Homework2.Receivers;

public interface IReceiver {
    void receivePackage();
}
