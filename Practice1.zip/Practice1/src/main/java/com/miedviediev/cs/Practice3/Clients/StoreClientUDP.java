package com.miedviediev.cs.Practice3.Clients;

public class StoreClientUDP {
}
