package com.miedviediev.cs.Homework2.Commands;

public interface ICommand {
    String execute(String[] message);
}
